﻿import urllib, urllib2, re, gzip, socket
import xbmc,xbmcplugin,xbmcgui,xbmcaddon,sys, os
import datetime
from BeautifulSoup import BeautifulSoup

#import m3u8

dialog = xbmcgui.Dialog()
progress = xbmcgui.DialogProgress()
addon_handle = int(sys.argv[1])
__scriptid__ = "plugin.video.hector"
addon = xbmcaddon.Addon(id=__scriptid__)

urlopen = urllib2.urlopen
Request = urllib2.Request

rootDir = addon.getAddonInfo('path')
if rootDir[-1] == ';':
    rootDir = rootDir[0:-1]
rootDir = xbmc.translatePath(rootDir)
hectoricon = xbmc.translatePath(os.path.join(rootDir, 'icon.png'))
profileDir = addon.getAddonInfo('profile')
profileDir = xbmc.translatePath(profileDir).decode("utf-8")
cookiePath = os.path.join(profileDir, 'cookies.lwp')

def GETFILTER():
    filterset = ""
    return txtfilter

USER_AGENT = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
headers = {'User-Agent': USER_AGENT,
           'Accept': '*/*',
           'Connection': 'keep-alive'}

def getHtml(url, referer=None, hdr=None, data=None):
    if not hdr:
        req = Request(url, data, headers)
    else:
        req = Request(url, data, hdr)
    if referer:
        req.add_header('Referer', referer)
    if data:
        req.add_header('Content-Length', len(data))
    response = urlopen(req, timeout=20)
    if response.info().get('Content-Encoding') == 'gzip':
        buf = StringIO( response.read())
        f = gzip.GzipFile(fileobj=buf)
        data = f.read()
        f.close()
    else:
        data = response.read()    
    response.close()
    xbmc.log("HTML DATA: "+str(data),2)
    return data
    
def MakeLink(name,url):
    return addDir(str(name), str(url), 3, "")



def IPTV(url):
    data = urllib2.urlopen(url).read()
    data = data.split("\n") # then split it into lines

    for line in data:
        if "#EXTM3U" in line:
            continue
        line = line.split("\n")
        linkdata =[]
        for line2 in line:
            #xbmc.log("FULL NAME: "+str(line),2)
            url = line2
            name = line2[11:]
            #linkdata.append(url,name)
            #if name == "":
            #    continue
            #if line==" ":
            #    continue
            #line = line.split(" ") 
        addDir(str(name), str(url), 3, "") # MakeLink(name,url)
        #xbmc.log(str(line),2)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))






def addDir(name, url, mode, iconimage, Folder=True):
    url = "plugin://plugin.video.live.streamspro/?fanart=C:\Users\bigla\AppData\Roaming\Kodi\addons\plugin.video.live.streamspro\fanart.jpg&mode=1&name=playlist&url="+url
    if url.startswith('plugin'):
        u = url
    else:
        u = (sys.argv[0] +
             "?url=" + urllib.quote_plus(url) +
             "&mode=" + str(mode) +
             "&name=" + urllib.quote_plus(name))
    ok = True
    liz = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=hectoricon)
    liz.setArt({'thumb': iconimage, 'icon': hectoricon})
    fanart = "" #os.path.join(rootDir, 'fanart.jpg')
    #liz.setProperty('IsPlayable', 'true')
    liz.setArt({'fanart': fanart})
    liz.setInfo(type="Video", infoLabels={"Title": name})
    ok = xbmcplugin.addDirectoryItem(handle=addon_handle, url=u, listitem=liz, isFolder=True)
    return ok
    
def PLAY(url, title):
    xbmc.Player().play(url)
    

def Main(): 
    addDir("Welcome to Hector!", "", "", hectoricon)
    addDir("", "", "", hectoricon)
    addDir("TEST", "http://vistatv.online/VistaEPG.m3u", 2, hectoricon)
    data = urllib2.urlopen("http://www.vistatv.online/m3u8/").read()
    data = data.split("\n") # then split it into lines
    count = 1
    for line in data:
        #line = line.split(" ") 
        addDir("[COLOR green]Hectors IPTV Server[/COLOR] :[COLOR gold]"+str(count)+"[/COLOR]", str(line), 2, hectoricon)
        #xbmc.log(str(line),2)
        count = count+1
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def getParams():
    param = []
    paramstring = sys.argv[2]
    if len(paramstring) >= 2:
        params = sys.argv[2]
        cleanedparams = params.replace('?', '')
        if params[len(params) - 1] == '/':
            params = params[0:len(params) - 2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)):
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if (len(splitparams)) == 2:
                param[splitparams[0]] = splitparams[1]

    return param


params = getParams()    
mode = None

try: url = urllib.unquote_plus(params["url"])
except: pass
try: name = urllib.unquote_plus(params["name"])
except: pass
try: mode = int(params["mode"])
except: pass
try: img = urllib.unquote_plus(params["img"])
except: pass

xbmc.log("MODE: "+str(mode),2)
if mode is None: Main()
elif mode == 1: parsem3u8(url)
elif mode == 2: IPTV(url)
elif mode == 3: PLAY(url, name)
    
