var.registers([])
var.get(u'console').callprop(u'log', Js(u'Worked!!!'))
