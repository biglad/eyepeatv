import time
import xbmc
import os
import xbmcgui
import urllib2
 
xbmc.executebuiltin("XBMC.AlarmClock('MTVBCS',XBMC.RunAddon(eyepeatv buold data),5,silent)")


	
