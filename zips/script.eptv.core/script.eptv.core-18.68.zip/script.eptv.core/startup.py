import time
import xbmc
import os
import xbmcgui
import urllib2
 
xbmc.executebuiltin("XBMC.AlarmClock('MTVBCS',XBMC.RunAddon(script.eptv.core),5,silent)")


	
