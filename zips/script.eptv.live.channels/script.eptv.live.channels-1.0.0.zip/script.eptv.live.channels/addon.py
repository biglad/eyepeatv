import xbmc
xbmc.executebuiltin('ActivateWindow(10700,"pvr://channels/tv/All channels/",return)')
xbmc.sleep(1000)
xbmc.executebuiltin('SendClick(28)')
exit()
