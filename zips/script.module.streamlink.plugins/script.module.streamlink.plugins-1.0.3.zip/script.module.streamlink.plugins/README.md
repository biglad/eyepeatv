# service.streamlink.plugins

This Plugin is an **example plugin** which won't get updated.

You can use this plugin in your repository for custom **streamlink** plugins

Just copy your `....py` file into the _plugins_ folder.

## streamlink

The compatible streamlink Kodi plugin for this is [Twilight0/service.streamlink.proxy(https://github.com/Twilight0/service.streamlink.proxy)

You can find it in [repository.twilight0.libs](https://github.com/Twilight0/repo.twilight0.libs)
