# -*- coding: UTF-8 -*-
import lolmessage


